# faceOvalBlur
This small program will detect face using dLib face detection and blur it with an oval shape.

# dependencies

OpenCV 3.x  (http://opencv.org/releases.html)
dLib 18.17.100 or later (http://dlib.net)
Python 2.7 or later
